import pandas as pd
import matplotlib.pyplot as plt

# Load data
df = pd.read_csv("kenya_hotel_data.csv")

# Plot hotel rooms
plt.figure(figsize=(10,5))
plt.plot(df['Year'], df['Hotel Rooms'], marker='o', color='skyblue')
plt.title('Growth of Hotel Rooms in Kenya (2017–2024)')
plt.xlabel('Year')
plt.ylabel('Number of Hotel Rooms')
plt.grid(True)
plt.tight_layout()
plt.savefig("hotel_rooms_growth.png")
plt.close()

# Plot international tourists
plt.figure(figsize=(10,5))
plt.plot(df['Year'], df['International Tourists'], marker='o', color='salmon')
plt.title('International Tourist Arrivals in Kenya (2017–2024)')
plt.xlabel('Year')
plt.ylabel('Tourists')
plt.grid(True)
plt.tight_layout()
plt.savefig("tourist_growth.png")
plt.close()
