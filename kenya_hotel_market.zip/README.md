# Kenya Hotel Market Analysis (2017–2024)

This repository contains a data-driven analysis of the hospitality supplies market in Kenya based on real data from 2017 to 2024. It includes Jupyter Notebook, Python script, dataset, and a full PDF report.

## Contents
- `kenya_hotel_market_analysis.ipynb`: Jupyter Notebook with visualizations and market insights.
- `kenya_hotel_market_analysis.py`: Python version of the notebook.
- `kenya_hotel_data.csv`: Dataset used for the analysis.
- `Laporan_Mysafi.pdf`: Final PDF report.
- `requirements.txt`: Python packages used.

## Source
- CEIC Data
- Kenya National Bureau of Statistics (KNBS)

## License
MIT License
